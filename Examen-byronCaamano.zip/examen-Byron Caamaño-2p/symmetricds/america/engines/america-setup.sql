# ============================================
# SymmetricDS Engine Configuration - AMÉRICA
# ============================================
#
# INSTRUCCIONES PARA EL ESTUDIANTE:
# Este archivo define la configuración específica del motor de sincronización
# para el nodo América. Aquí se definen las tablas a replicar, triggers,
# routers y transformaciones de datos.
#
# TAREAS:
# 1. Configurar los grupos de nodos (node groups)
# 2. Definir los canales de sincronización
# 3. Configurar los triggers para las 4 tablas
# 4. Definir los routers (reglas de enrutamiento)
# 5. Configurar los group links (vínculos entre grupos)
#
# ============================================

# --------------------------------------------
# Definición de Grupos de Nodos
# --------------------------------------------
# COMPLETAR: Define los grupos de nodos que participarán en la replicación
# 
# Ejemplo:
# insert into sym_node_group (node_group_id, description) values ('america-store', 'Nodo América');
# insert into sym_node_group (node_group_id, description) values ('europe-store', 'Nodo Europa');

# HINT: Necesitas 2 grupos: uno para América y otro para Europa


# --------------------------------------------
# Enlaces entre Grupos (Group Links)
# --------------------------------------------
# COMPLETAR: Define cómo se comunican los grupos entre sí
# 
# Los enlaces deben ser BIDIRECCIONALES para replicación bidireccional
# 
# Ejemplo:
# insert into sym_node_group_link (source_node_group_id, target_node_group_id, data_event_action) 
# values ('america-store', 'europe-store', 'W');
#
# Donde data_event_action puede ser:
# - 'W' = Wait (esperar y sincronizar)
# - 'P' = Push (solo empujar)
# - 'I' = Ignore (ignorar)

# HINT: Necesitas 2 enlaces: América -> Europa y Europa -> América


# --------------------------------------------
# Definición de Canales
# --------------------------------------------
# COMPLETAR: Define los canales por los que viajarán los datos
#
# Los canales agrupan tablas relacionadas y controlan el orden de sincronización
# 
# Ejemplo:
# insert into sym_channel (channel_id, processing_order, max_batch_size, enabled, description)
# values ('products_channel', 10, 10000, 1, 'Canal para productos y catálogo');

# HINT: Puedes crear canales separados para:
# - products (productos)
# - inventory (inventario)
# - customers (clientes)
# - promotions (promociones)
# O un canal general para todos


# --------------------------------------------
# Definición de Triggers
# --------------------------------------------
# COMPLETAR: Define los triggers que capturarán cambios en las tablas
#
# Los triggers se crean automáticamente en las tablas que quieres replicar
# 
# Ejemplo:
# insert into sym_trigger (trigger_id, source_table_name, channel_id, 
#   last_update_time, create_time)
# values ('products_trigger', 'products', 'products_channel', 
#   current_timestamp, current_timestamp);

# HINT: Necesitas 4 triggers, uno para cada tabla:
# - products
# - inventory
# - customers
# - promotions


# --------------------------------------------
# Definición de Routers
# --------------------------------------------
# COMPLETAR: Define los routers que determinan a dónde van los datos
#
# Los routers especifican qué nodos reciben qué datos
# 
# Router types comunes:
# - default: replica todo a todos los nodos del grupo destino
# - column: filtra por valor de columna
# - bsh: usa BeanShell script para lógica compleja
#
# Ejemplo:
# insert into sym_router (router_id, source_node_group_id, target_node_group_id, 
#   router_type, create_time, last_update_time)
# values ('america_2_europe', 'america-store', 'europe-store', 
#   'default', current_timestamp, current_timestamp);

# HINT: Necesitas 2 routers:
# - américa -> europa (para enviar cambios)
# - europa -> américa (para recibir cambios)


# --------------------------------------------
# Vinculación de Triggers con Routers
# --------------------------------------------
# COMPLETAR: Vincula cada trigger con los routers apropiados
#
# Esto determina qué cambios capturados por los triggers
# se envían a través de qué routers
# 
# Ejemplo:
# insert into sym_trigger_router (trigger_id, router_id, initial_load_order, 
#   last_update_time, create_time)
# values ('products_trigger', 'america_2_europe', 100, 
#   current_timestamp, current_timestamp);

# HINT: Cada trigger debe estar vinculado a los routers apropiados
# Si tienes 4 triggers y 2 routers, necesitarás múltiples combinaciones


# --------------------------------------------
# Carga Inicial (Initial Load)
# --------------------------------------------
# COMPLETAR: Configura qué tablas se cargarán inicialmente
#
# La carga inicial sincroniza los datos existentes cuando un nodo
# se conecta por primera vez
#
# Ejemplo:
# insert into sym_trigger (trigger_id, source_table_name, channel_id,
#   sync_on_insert, sync_on_update, sync_on_delete, initial_load_enabled,
#   last_update_time, create_time)
# values ('products_trigger', 'products', 'products_channel',
#   1, 1, 1, 1,
#   current_timestamp, current_timestamp);

# HINT: Habilita sync_on_insert, sync_on_update, sync_on_delete para cada trigger


# ============================================
# GUÍA DE CONFIGURACIÓN SQL:
#
# Este archivo debe contener sentencias SQL INSERT que configurarán
# las tablas de SymmetricDS (sym_*) cuando el nodo se inicie.
#
# Las tablas principales a configurar son:
# 1. sym_node_group - Define los grupos de nodos
# 2. sym_node_group_link - Enlaces bidireccionales entre grupos
# 3. sym_channel - Canales de sincronización
# 4. sym_trigger - Triggers para capturar cambios
# 5. sym_router - Routers para enrutar cambios
# 6. sym_trigger_router - Vinculación de triggers con routers
#
# RECURSOS:
# - Documentación SymmetricDS: https://www.symmetricds.org/docs
# - Ver docs/SYMMETRICDS_GUIDE.md para ejemplos completos
#
# ============================================

-- ESCRIBE TU CONFIGURACIÓN SQL AQUÍ:

-- 1. GRUPOS DE NODOS
insert into sym_node_group (node_group_id, description) 
values ('america-store', 'Stores in America region');

insert into sym_node_group (node_group_id, description) 
values ('europe-store', 'Stores in Europe region');

-- 2. ENLACES BIDIRECCIONALES
insert into sym_node_group_link 
  (source_node_group_id, target_node_group_id, data_event_action) 
values ('america-store', 'europe-store', 'W');

insert into sym_node_group_link 
  (source_node_group_id, target_node_group_id, data_event_action) 
values ('europe-store', 'america-store', 'W');

-- 3. CANALES
insert into sym_channel 
  (channel_id, processing_order, max_batch_size, enabled, description)
values ('products_channel', 10, 10000, 1, 'Channel for products catalog');

insert into sym_channel 
  (channel_id, processing_order, max_batch_size, enabled, description)
values ('inventory_channel', 20, 10000, 1, 'Channel for inventory data');

insert into sym_channel 
  (channel_id, processing_order, max_batch_size, enabled, description)
values ('customers_channel', 30, 10000, 1, 'Channel for customer data');

insert into sym_channel 
  (channel_id, processing_order, max_batch_size, enabled, description)
values ('promotions_channel', 40, 10000, 1, 'Channel for promotions');

-- 4. TRIGGERS
insert into sym_trigger 
  (trigger_id, source_table_name, channel_id, 
   last_update_time, create_time)
values ('products_trigger', 'products', 'products_channel', 
   current_timestamp, current_timestamp);

insert into sym_trigger 
  (trigger_id, source_table_name, channel_id, 
   last_update_time, create_time)
values ('inventory_trigger', 'inventory', 'inventory_channel', 
   current_timestamp, current_timestamp);

insert into sym_trigger 
  (trigger_id, source_table_name, channel_id, 
   last_update_time, create_time)
values ('customers_trigger', 'customers', 'customers_channel', 
   current_timestamp, current_timestamp);

insert into sym_trigger 
  (trigger_id, source_table_name, channel_id, 
   last_update_time, create_time)
values ('promotions_trigger', 'promotions', 'promotions_channel', 
   current_timestamp, current_timestamp);

-- 5. ROUTERS
insert into sym_router 
  (router_id, source_node_group_id, target_node_group_id, 
   router_type, create_time, last_update_time)
values ('america_to_europe', 'america-store', 'europe-store', 
   'default', current_timestamp, current_timestamp);

insert into sym_router 
  (router_id, source_node_group_id, target_node_group_id, 
   router_type, create_time, last_update_time)
values ('europe_to_america', 'europe-store', 'america-store', 
   'default', current_timestamp, current_timestamp);

-- 6. TRIGGER ROUTERS
insert into sym_trigger_router 
  (trigger_id, router_id, initial_load_order, 
   last_update_time, create_time)
values ('products_trigger', 'america_to_europe', 100, 
   current_timestamp, current_timestamp);

insert into sym_trigger_router 
  (trigger_id, router_id, initial_load_order, 
   last_update_time, create_time)
values ('products_trigger', 'europe_to_america', 100, 
   current_timestamp, current_timestamp);

insert into sym_trigger_router 
  (trigger_id, router_id, initial_load_order, 
   last_update_time, create_time)
values ('inventory_trigger', 'america_to_europe', 200, 
   current_timestamp, current_timestamp);

insert into sym_trigger_router 
  (trigger_id, router_id, initial_load_order, 
   last_update_time, create_time)
values ('inventory_trigger', 'europe_to_america', 200, 
   current_timestamp, current_timestamp);

insert into sym_trigger_router 
  (trigger_id, router_id, initial_load_order, 
   last_update_time, create_time)
values ('customers_trigger', 'america_to_europe', 300, 
   current_timestamp, current_timestamp);

insert into sym_trigger_router 
  (trigger_id, router_id, initial_load_order, 
   last_update_time, create_time)
values ('customers_trigger', 'europe_to_america', 300, 
   current_timestamp, current_timestamp);

insert into sym_trigger_router 
  (trigger_id, router_id, initial_load_order, 
   last_update_time, create_time)
values ('promotions_trigger', 'america_to_europe', 400, 
   current_timestamp, current_timestamp);

insert into sym_trigger_router 
  (trigger_id, router_id, initial_load_order, 
   last_update_time, create_time)
values ('promotions_trigger', 'europe_to_america', 400, 
   current_timestamp, current_timestamp);
